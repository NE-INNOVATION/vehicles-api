module.exports = {
    app: require('./routes')
}